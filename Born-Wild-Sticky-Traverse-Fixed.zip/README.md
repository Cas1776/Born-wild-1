# Born Wild - Sticky Surface Traversal

Demo showing multi-surface traversal for sticky creatures.
Stick to tree branches and rock walls, and move strategically.

## Controls
- W/A/S/D: Move
- F: Stick or unstick to nearby surface

## Features
- Attach to top of trees or side of rocks
- Detects surface type and aligns properly