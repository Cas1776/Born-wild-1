import pygame
from core.player import Player
from core.hud import HUD

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.player = Player()
        self.hud = HUD()

        # stickable surfaces: tree (horizontal), rock wall (vertical)
        self.surfaces = [
            {"rect": pygame.Rect(300, 150, 200, 20), "type": "tree", "stickable": True},  # branch
            {"rect": pygame.Rect(600, 250, 20, 200), "type": "rock", "stickable": True},  # cliff
        ]

    def update(self):
        self.screen.fill((20, 20, 20))
        for s in self.surfaces:
            color = (139, 69, 19) if s["type"] == "tree" else (128, 128, 128)
            pygame.draw.rect(self.screen, color, s["rect"])

        self.player.update(self.surfaces)
        self.player.draw(self.screen)
        self.hud.draw(self.screen, self.player)