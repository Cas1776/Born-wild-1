import pygame

class HUD:
    def __init__(self):
        self.font = pygame.font.SysFont("Arial", 18)

    def draw(self, screen, player):
        surface = player.stuck_surface["type"] if player.stuck_surface else "None"
        side = player.stick_side if player.stick_side else "None"
        status = "Stuck" if player.is_stuck else "Grounded"
        text = self.font.render(f"Status: {status} | Surface: {surface} | Side: {side} | F = Stick, Space = Jump", True, (255, 255, 255))
        screen.blit(text, (10, 10))