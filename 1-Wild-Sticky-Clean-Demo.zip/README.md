# Born Wild - Sticky Climber (Clean Demo)

## Features
- Move with A/D
- Jump with Space (on ground)
- Stick/unstick to trees and rocks using F

## Setup
1. pip install -r requirements.txt
2. python main.py