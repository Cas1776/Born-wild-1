import pygame

class Player:
    def __init__(self):
        self.x, self.y = 300, 450
        self.speed = 4
        self.width, self.height = 40, 40
        self.image = pygame.Surface((self.width, self.height))
        self.image.fill((200, 255, 200))

        self.can_stick = True
        self.is_stuck = False
        self.stuck_surface = None
        self.stick_side = None  # 'top', 'left', etc.

    def update(self, surfaces):
        keys = pygame.key.get_pressed()

        if not self.is_stuck:
            if keys[pygame.K_a]: self.x -= self.speed
            if keys[pygame.K_d]: self.x += self.speed
            if keys[pygame.K_w]: self.y -= self.speed
            if keys[pygame.K_s]: self.y += self.speed

        if keys[pygame.K_f]:
            player_rect = pygame.Rect(self.x, self.y, self.width, self.height)
            for s in surfaces:
                if s["stickable"] and player_rect.colliderect(s["rect"]):
                    self.is_stuck = not self.is_stuck
                    self.stuck_surface = s if self.is_stuck else None
                    self.stick_side = "top" if s["rect"].height <= 30 else "left"
                    if self.is_stuck:
                        if self.stick_side == "top":
                            self.y = s["rect"].top - self.height
                        elif self.stick_side == "left":
                            self.x = s["rect"].left - self.width
                    break

        if self.is_stuck and self.stuck_surface:
            s = self.stuck_surface["rect"]
            if self.stick_side == "top":
                self.y = s.top - self.height
            elif self.stick_side == "left":
                self.x = s.left - self.width

    def draw(self, screen):
        flipped = pygame.transform.flip(self.image, False, True) if self.stick_side == "top" else self.image
        rotated = pygame.transform.rotate(flipped, 90) if self.stick_side == "left" else flipped
        screen.blit(rotated, (self.x, self.y))